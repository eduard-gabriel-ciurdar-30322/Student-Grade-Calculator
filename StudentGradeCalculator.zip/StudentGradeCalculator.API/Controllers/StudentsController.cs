using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentGradeCalculator.API.Data;
using StudentGradeCalculator.Shared;

namespace StudentGradeCalculator.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StudentsController(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// GET: api/students
        /// Returns all students, with optional filtering by name, subject, and passed-only.
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudents(
            [FromQuery] string? name = null,
            [FromQuery] string? subject = null,
            [FromQuery] bool? passedOnly = null)
        {
            IQueryable<Student> query = _context.Students;

            // Filter by name (case-insensitive partial match)
            if (!string.IsNullOrWhiteSpace(name))
            {
                query = query.Where(s => s.Name.ToLower().Contains(name.ToLower()));
            }

            // Filter by subject (exact match)
            if (!string.IsNullOrWhiteSpace(subject) && subject != "All Subjects")
            {
                query = query.Where(s => s.Subject == subject);
            }

            // Filter by passed only (grade >= 5.0)
            if (passedOnly == true)
            {
                query = query.Where(s => s.Grade >= 5.0);
            }

            var students = await query.OrderByDescending(s => s.DateAdded).ToListAsync();
            return Ok(students);
        }

        /// <summary>
        /// GET: api/students/{id}
        /// Returns a single student by ID.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetStudent(int id)
        {
            var student = await _context.Students.FindAsync(id);

            if (student == null)
            {
                return NotFound(new { message = $"Student with ID {id} not found." });
            }

            return Ok(student);
        }

        /// <summary>
        /// POST: api/students
        /// Creates a new student record.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Student>> CreateStudent([FromBody] Student student)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            student.DateAdded = DateTime.Now;
            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetStudent), new { id = student.Id }, student);
        }

        /// <summary>
        /// PUT: api/students/{id}
        /// Updates an existing student record.
        /// </summary>
        [HttpPut("{id}")]
        public async Task<ActionResult<Student>> UpdateStudent(int id, [FromBody] Student student)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existing = await _context.Students.FindAsync(id);
            if (existing == null)
            {
                return NotFound(new { message = $"Student with ID {id} not found." });
            }

            existing.Name = student.Name;
            existing.Subject = student.Subject;
            existing.Grade = student.Grade;
            existing.Semester = student.Semester;
            existing.IsFinalExam = student.IsFinalExam;

            await _context.SaveChangesAsync();

            return Ok(existing);
        }

        /// <summary>
        /// DELETE: api/students/{id}
        /// Deletes a student record.
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound(new { message = $"Student with ID {id} not found." });
            }

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();

            return Ok(new { message = $"Student '{student.Name}' deleted successfully." });
        }
    }
}
