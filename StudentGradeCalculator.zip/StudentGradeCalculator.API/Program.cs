using Microsoft.EntityFrameworkCore;
using StudentGradeCalculator.API.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();

// Configure EF Core with SQL Server LocalDB
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=StudentGradesDB;Trusted_Connection=True;"));

// Configure CORS to allow the WinForms client to connect
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Auto-create / migrate the database on startup and seed data
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    // Seed 6 students if the database is empty
    if (!db.Students.Any())
    {
        db.Students.AddRange(
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Maria Popescu",
                Subject = "Mathematics",
                Grade = 9.50,
                Semester = "Semester 1",
                IsFinalExam = true,
                DateAdded = DateTime.Now
            },
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Andrei Ionescu",
                Subject = "Physics",
                Grade = 7.25,
                Semester = "Semester 1",
                IsFinalExam = false,
                DateAdded = DateTime.Now
            },
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Elena Dumitrescu",
                Subject = "Computer Science",
                Grade = 10.00,
                Semester = "Semester 2",
                IsFinalExam = true,
                DateAdded = DateTime.Now
            },
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Alexandru Radu",
                Subject = "English",
                Grade = 4.50,
                Semester = "Semester 1",
                IsFinalExam = true,
                DateAdded = DateTime.Now
            },
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Ioana Marin",
                Subject = "Chemistry",
                Grade = 8.75,
                Semester = "Semester 2",
                IsFinalExam = false,
                DateAdded = DateTime.Now
            },
            new StudentGradeCalculator.Shared.Student
            {
                Name = "Cristian Popa",
                Subject = "Electronics",
                Grade = 6.00,
                Semester = "Semester 1",
                IsFinalExam = true,
                DateAdded = DateTime.Now
            }
        );
        db.SaveChanges();
    }
}

// Configure the HTTP pipeline
app.UseCors("AllowAll");
app.MapControllers();

app.Run();
