using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using StudentGradeCalculator.Shared;

namespace StudentGradeCalculator.Client.Services
{
    public class StudentApiService
    {
        private readonly HttpClient _httpClient;
        private readonly JsonSerializerOptions _jsonOptions;

        public StudentApiService(string baseUrl = "http://localhost:5000")
        {
            _httpClient = new HttpClient { BaseAddress = new Uri(baseUrl) };
            _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        }

        public async Task<List<Student>> GetStudentsAsync(string? searchName = null, string? subject = null, bool? passedOnly = null)
        {
            var qp = new List<string>();
            if (!string.IsNullOrWhiteSpace(searchName)) qp.Add($"name={Uri.EscapeDataString(searchName)}");
            if (!string.IsNullOrWhiteSpace(subject) && subject != "All Subjects") qp.Add($"subject={Uri.EscapeDataString(subject)}");
            if (passedOnly == true) qp.Add("passedOnly=true");
            string query = qp.Count > 0 ? "?" + string.Join("&", qp) : "";

            var response = await _httpClient.GetAsync($"api/students{query}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<Student>>(_jsonOptions) ?? new List<Student>();
        }

        public async Task<Student?> GetStudentAsync(int id)
        {
            var response = await _httpClient.GetAsync($"api/students/{id}");
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<Student>(_jsonOptions);
        }

        public async Task<Student?> CreateStudentAsync(Student student)
        {
            var json = JsonSerializer.Serialize(student, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("api/students", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Student>(_jsonOptions);
        }

        public async Task<Student?> UpdateStudentAsync(int id, Student student)
        {
            var json = JsonSerializer.Serialize(student, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync($"api/students/{id}", content);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<Student>(_jsonOptions);
        }

        public async Task<bool> DeleteStudentAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"api/students/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> IsApiAvailableAsync()
        {
            try { var r = await _httpClient.GetAsync("api/students"); return r.IsSuccessStatusCode; }
            catch { return false; }
        }
    }
}
