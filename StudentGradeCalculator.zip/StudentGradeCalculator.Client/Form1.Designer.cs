namespace StudentGradeCalculator.Client
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // === Panel: Left Input Panel ===
            this.panelInput = new Panel();
            this.panelInput.BackColor = Color.FromArgb(30, 30, 46);
            this.panelInput.Dock = DockStyle.Left;
            this.panelInput.Width = 380;
            this.panelInput.Padding = new Padding(20);

            // === Title Label ===
            this.lblTitle = new Label();
            this.lblTitle.Text = "\U0001F4DA Student Grade Calculator";
            this.lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.FromArgb(137, 180, 250);
            this.lblTitle.Location = new Point(20, 15);
            this.lblTitle.Size = new Size(340, 40);
            this.lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            // === Connection Status ===
            this.lblConnectionStatus = new Label();
            this.lblConnectionStatus.Text = "\u26A0\uFE0F Connecting to API...";
            this.lblConnectionStatus.Font = new Font("Segoe UI", 8F, FontStyle.Italic);
            this.lblConnectionStatus.ForeColor = Color.FromArgb(249, 226, 175);
            this.lblConnectionStatus.Location = new Point(20, 55);
            this.lblConnectionStatus.Size = new Size(340, 18);
            this.lblConnectionStatus.TextAlign = ContentAlignment.MiddleCenter;

            // === Label: Student Name ===
            this.lblName = new Label();
            this.lblName.Text = "Student Name:";
            this.lblName.Font = new Font("Segoe UI", 10F);
            this.lblName.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblName.Location = new Point(20, 78);
            this.lblName.Size = new Size(130, 25);

            // === TextBox: Student Name ===
            this.txtName = new TextBox();
            this.txtName.Font = new Font("Segoe UI", 10F);
            this.txtName.BackColor = Color.FromArgb(49, 50, 68);
            this.txtName.ForeColor = Color.FromArgb(205, 214, 244);
            this.txtName.BorderStyle = BorderStyle.FixedSingle;
            this.txtName.Location = new Point(20, 103);
            this.txtName.Size = new Size(335, 30);
            this.txtName.PlaceholderText = "Enter student name...";

            // === Label: Subject ===
            this.lblSubject = new Label();
            this.lblSubject.Text = "Subject:";
            this.lblSubject.Font = new Font("Segoe UI", 10F);
            this.lblSubject.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblSubject.Location = new Point(20, 140);
            this.lblSubject.Size = new Size(130, 25);

            // === ComboBox: Subject ===
            this.cmbSubject = new ComboBox();
            this.cmbSubject.Font = new Font("Segoe UI", 10F);
            this.cmbSubject.BackColor = Color.FromArgb(49, 50, 68);
            this.cmbSubject.ForeColor = Color.FromArgb(205, 214, 244);
            this.cmbSubject.FlatStyle = FlatStyle.Flat;
            this.cmbSubject.Location = new Point(20, 165);
            this.cmbSubject.Size = new Size(335, 30);
            this.cmbSubject.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbSubject.Items.AddRange(new object[] {
                "Mathematics", "Physics", "Computer Science", "English",
                "Chemistry", "Biology", "History", "Electronics"
            });

            // === Label: Grade ===
            this.lblGrade = new Label();
            this.lblGrade.Text = "Grade (1-10):";
            this.lblGrade.Font = new Font("Segoe UI", 10F);
            this.lblGrade.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblGrade.Location = new Point(20, 205);
            this.lblGrade.Size = new Size(130, 25);

            // === TextBox: Grade ===
            this.txtGrade = new TextBox();
            this.txtGrade.Font = new Font("Segoe UI", 10F);
            this.txtGrade.BackColor = Color.FromArgb(49, 50, 68);
            this.txtGrade.ForeColor = Color.FromArgb(205, 214, 244);
            this.txtGrade.BorderStyle = BorderStyle.FixedSingle;
            this.txtGrade.Location = new Point(20, 230);
            this.txtGrade.Size = new Size(160, 30);
            this.txtGrade.PlaceholderText = "e.g. 8.50";

            // === Label: Grade Preview ===
            this.lblGradePreview = new Label();
            this.lblGradePreview.Text = "";
            this.lblGradePreview.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.lblGradePreview.ForeColor = Color.FromArgb(166, 227, 161);
            this.lblGradePreview.Location = new Point(190, 230);
            this.lblGradePreview.Size = new Size(165, 30);
            this.lblGradePreview.TextAlign = ContentAlignment.MiddleLeft;

            // === Label: Semester ===
            this.lblSemester = new Label();
            this.lblSemester.Text = "Semester:";
            this.lblSemester.Font = new Font("Segoe UI", 10F);
            this.lblSemester.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblSemester.Location = new Point(20, 268);
            this.lblSemester.Size = new Size(130, 25);

            // === ComboBox: Semester ===
            this.cmbSemester = new ComboBox();
            this.cmbSemester.Font = new Font("Segoe UI", 10F);
            this.cmbSemester.BackColor = Color.FromArgb(49, 50, 68);
            this.cmbSemester.ForeColor = Color.FromArgb(205, 214, 244);
            this.cmbSemester.FlatStyle = FlatStyle.Flat;
            this.cmbSemester.Location = new Point(20, 293);
            this.cmbSemester.Size = new Size(335, 30);
            this.cmbSemester.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbSemester.Items.AddRange(new object[] { "Semester 1", "Semester 2" });

            // === CheckBox: Final Exam ===
            this.chkFinalExam = new CheckBox();
            this.chkFinalExam.Text = "  Final Exam";
            this.chkFinalExam.Font = new Font("Segoe UI", 10F);
            this.chkFinalExam.ForeColor = Color.FromArgb(205, 214, 244);
            this.chkFinalExam.Location = new Point(20, 333);
            this.chkFinalExam.Size = new Size(335, 30);
            this.chkFinalExam.FlatStyle = FlatStyle.Flat;

            // === Label: Validation ===
            this.lblValidation = new Label();
            this.lblValidation.Text = "";
            this.lblValidation.Font = new Font("Segoe UI", 9F, FontStyle.Italic);
            this.lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
            this.lblValidation.Location = new Point(20, 368);
            this.lblValidation.Size = new Size(335, 25);

            // === Buttons ===
            this.btnAdd = new Button();
            this.btnAdd.Text = "\u2795 Add Grade";
            this.btnAdd.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnAdd.BackColor = Color.FromArgb(137, 180, 250);
            this.btnAdd.ForeColor = Color.FromArgb(30, 30, 46);
            this.btnAdd.FlatStyle = FlatStyle.Flat;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.Location = new Point(20, 400);
            this.btnAdd.Size = new Size(160, 40);
            this.btnAdd.Cursor = Cursors.Hand;

            this.btnUpdate = new Button();
            this.btnUpdate.Text = "\u270F\uFE0F Update";
            this.btnUpdate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnUpdate.BackColor = Color.FromArgb(249, 226, 175);
            this.btnUpdate.ForeColor = Color.FromArgb(30, 30, 46);
            this.btnUpdate.FlatStyle = FlatStyle.Flat;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.Location = new Point(195, 400);
            this.btnUpdate.Size = new Size(160, 40);
            this.btnUpdate.Cursor = Cursors.Hand;
            this.btnUpdate.Enabled = false;

            this.btnDelete = new Button();
            this.btnDelete.Text = "\U0001F5D1\uFE0F Delete";
            this.btnDelete.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnDelete.BackColor = Color.FromArgb(243, 139, 168);
            this.btnDelete.ForeColor = Color.FromArgb(30, 30, 46);
            this.btnDelete.FlatStyle = FlatStyle.Flat;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.Location = new Point(20, 450);
            this.btnDelete.Size = new Size(160, 40);
            this.btnDelete.Cursor = Cursors.Hand;
            this.btnDelete.Enabled = false;

            this.btnClear = new Button();
            this.btnClear.Text = "\U0001F9F9 Clear Form";
            this.btnClear.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnClear.BackColor = Color.FromArgb(116, 199, 236);
            this.btnClear.ForeColor = Color.FromArgb(30, 30, 46);
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.Location = new Point(195, 450);
            this.btnClear.Size = new Size(160, 40);
            this.btnClear.Cursor = Cursors.Hand;

            // === Statistics ===
            this.lblStatsHeader = new Label();
            this.lblStatsHeader.Text = "\U0001F4CA Statistics";
            this.lblStatsHeader.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblStatsHeader.ForeColor = Color.FromArgb(137, 180, 250);
            this.lblStatsHeader.Location = new Point(20, 505);
            this.lblStatsHeader.Size = new Size(335, 30);

            this.lblStats = new Label();
            this.lblStats.Text = "No grades added yet.";
            this.lblStats.Font = new Font("Segoe UI", 9F);
            this.lblStats.ForeColor = Color.FromArgb(166, 227, 161);
            this.lblStats.Location = new Point(20, 535);
            this.lblStats.Size = new Size(335, 80);

            // === Add controls to left panel ===
            this.panelInput.Controls.Add(this.lblTitle);
            this.panelInput.Controls.Add(this.lblConnectionStatus);
            this.panelInput.Controls.Add(this.lblName);
            this.panelInput.Controls.Add(this.txtName);
            this.panelInput.Controls.Add(this.lblSubject);
            this.panelInput.Controls.Add(this.cmbSubject);
            this.panelInput.Controls.Add(this.lblGrade);
            this.panelInput.Controls.Add(this.txtGrade);
            this.panelInput.Controls.Add(this.lblGradePreview);
            this.panelInput.Controls.Add(this.lblSemester);
            this.panelInput.Controls.Add(this.cmbSemester);
            this.panelInput.Controls.Add(this.chkFinalExam);
            this.panelInput.Controls.Add(this.lblValidation);
            this.panelInput.Controls.Add(this.btnAdd);
            this.panelInput.Controls.Add(this.btnUpdate);
            this.panelInput.Controls.Add(this.btnDelete);
            this.panelInput.Controls.Add(this.btnClear);
            this.panelInput.Controls.Add(this.lblStatsHeader);
            this.panelInput.Controls.Add(this.lblStats);

            // === Panel: Right Content ===
            this.panelContent = new Panel();
            this.panelContent.BackColor = Color.FromArgb(24, 24, 37);
            this.panelContent.Dock = DockStyle.Fill;
            this.panelContent.Padding = new Padding(20);

            // === Grid Title ===
            this.lblGridTitle = new Label();
            this.lblGridTitle.Text = "\U0001F4CB Grade Records";
            this.lblGridTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblGridTitle.ForeColor = Color.FromArgb(137, 180, 250);
            this.lblGridTitle.Location = new Point(20, 15);
            this.lblGridTitle.Size = new Size(300, 35);

            // === Search ===
            this.lblSearch = new Label();
            this.lblSearch.Text = "\U0001F50D Search:";
            this.lblSearch.Font = new Font("Segoe UI", 10F);
            this.lblSearch.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblSearch.Location = new Point(20, 55);
            this.lblSearch.Size = new Size(80, 25);

            this.txtSearch = new TextBox();
            this.txtSearch.Font = new Font("Segoe UI", 10F);
            this.txtSearch.BackColor = Color.FromArgb(49, 50, 68);
            this.txtSearch.ForeColor = Color.FromArgb(205, 214, 244);
            this.txtSearch.BorderStyle = BorderStyle.FixedSingle;
            this.txtSearch.Location = new Point(100, 52);
            this.txtSearch.Size = new Size(250, 30);
            this.txtSearch.PlaceholderText = "Search by name or subject...";

            // === Filter ===
            this.lblFilter = new Label();
            this.lblFilter.Text = "Filter:";
            this.lblFilter.Font = new Font("Segoe UI", 10F);
            this.lblFilter.ForeColor = Color.FromArgb(205, 214, 244);
            this.lblFilter.Location = new Point(370, 55);
            this.lblFilter.Size = new Size(50, 25);

            this.cmbFilter = new ComboBox();
            this.cmbFilter.Font = new Font("Segoe UI", 10F);
            this.cmbFilter.BackColor = Color.FromArgb(49, 50, 68);
            this.cmbFilter.ForeColor = Color.FromArgb(205, 214, 244);
            this.cmbFilter.FlatStyle = FlatStyle.Flat;
            this.cmbFilter.Location = new Point(420, 52);
            this.cmbFilter.Size = new Size(180, 30);
            this.cmbFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbFilter.Items.AddRange(new object[] {
                "All Subjects", "Mathematics", "Physics", "Computer Science",
                "English", "Chemistry", "Biology", "History", "Electronics"
            });
            this.cmbFilter.SelectedIndex = 0;

            this.chkShowPassed = new CheckBox();
            this.chkShowPassed.Text = "  Show only passed";
            this.chkShowPassed.Font = new Font("Segoe UI", 9F);
            this.chkShowPassed.ForeColor = Color.FromArgb(205, 214, 244);
            this.chkShowPassed.Location = new Point(620, 55);
            this.chkShowPassed.Size = new Size(170, 25);
            this.chkShowPassed.FlatStyle = FlatStyle.Flat;

            // === DataGridView ===
            this.dgvGrades = new DataGridView();
            this.dgvGrades.Location = new Point(20, 90);
            this.dgvGrades.Size = new Size(740, 320);
            this.dgvGrades.BackgroundColor = Color.FromArgb(30, 30, 46);
            this.dgvGrades.GridColor = Color.FromArgb(69, 71, 90);
            this.dgvGrades.DefaultCellStyle.BackColor = Color.FromArgb(30, 30, 46);
            this.dgvGrades.DefaultCellStyle.ForeColor = Color.FromArgb(205, 214, 244);
            this.dgvGrades.DefaultCellStyle.SelectionBackColor = Color.FromArgb(137, 180, 250);
            this.dgvGrades.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 30, 46);
            this.dgvGrades.DefaultCellStyle.Font = new Font("Segoe UI", 9F);
            this.dgvGrades.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(49, 50, 68);
            this.dgvGrades.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(137, 180, 250);
            this.dgvGrades.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.dgvGrades.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            this.dgvGrades.EnableHeadersVisualStyles = false;
            this.dgvGrades.RowHeadersVisible = false;
            this.dgvGrades.AllowUserToAddRows = false;
            this.dgvGrades.AllowUserToDeleteRows = false;
            this.dgvGrades.ReadOnly = true;
            this.dgvGrades.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvGrades.MultiSelect = false;
            this.dgvGrades.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGrades.BorderStyle = BorderStyle.None;
            this.dgvGrades.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvGrades.RowTemplate.Height = 35;
            this.dgvGrades.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            // DataGridView Columns
            this.dgvGrades.Columns.Add("colName", "Student Name");
            this.dgvGrades.Columns.Add("colSubject", "Subject");
            this.dgvGrades.Columns.Add("colGrade", "Grade");
            this.dgvGrades.Columns.Add("colLetter", "Letter");
            this.dgvGrades.Columns.Add("colSemester", "Semester");
            this.dgvGrades.Columns.Add("colExamType", "Exam Type");
            this.dgvGrades.Columns.Add("colStatus", "Status");
            this.dgvGrades.Columns.Add("colDate", "Date Added");
            this.dgvGrades.Columns["colGrade"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            this.dgvGrades.Columns["colLetter"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            this.dgvGrades.Columns["colStatus"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // === Activity Log ===
            this.lblLogTitle = new Label();
            this.lblLogTitle.Text = "\U0001F4DD Activity Log";
            this.lblLogTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            this.lblLogTitle.ForeColor = Color.FromArgb(137, 180, 250);
            this.lblLogTitle.Location = new Point(20, 420);
            this.lblLogTitle.Size = new Size(300, 30);
            this.lblLogTitle.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;

            this.lstLog = new ListBox();
            this.lstLog.Font = new Font("Consolas", 9F);
            this.lstLog.BackColor = Color.FromArgb(30, 30, 46);
            this.lstLog.ForeColor = Color.FromArgb(166, 227, 161);
            this.lstLog.BorderStyle = BorderStyle.FixedSingle;
            this.lstLog.Location = new Point(20, 455);
            this.lstLog.Size = new Size(740, 130);
            this.lstLog.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            // === Add controls to right panel ===
            this.panelContent.Controls.Add(this.lblGridTitle);
            this.panelContent.Controls.Add(this.lblSearch);
            this.panelContent.Controls.Add(this.txtSearch);
            this.panelContent.Controls.Add(this.lblFilter);
            this.panelContent.Controls.Add(this.cmbFilter);
            this.panelContent.Controls.Add(this.chkShowPassed);
            this.panelContent.Controls.Add(this.dgvGrades);
            this.panelContent.Controls.Add(this.lblLogTitle);
            this.panelContent.Controls.Add(this.lstLog);

            // === Form Setup ===
            this.SuspendLayout();
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(1160, 620);
            this.BackColor = Color.FromArgb(24, 24, 37);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelInput);
            this.MinimumSize = new Size(1000, 600);
            this.Name = "Form1";
            this.Text = "Student Grade Calculator - Client";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
        }

        #endregion

        // Left Panel
        private Panel panelInput;
        private Label lblTitle;
        private Label lblConnectionStatus;
        private Label lblName;
        private TextBox txtName;
        private Label lblSubject;
        private ComboBox cmbSubject;
        private Label lblGrade;
        private TextBox txtGrade;
        private Label lblGradePreview;
        private Label lblSemester;
        private ComboBox cmbSemester;
        private CheckBox chkFinalExam;
        private Label lblValidation;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private Label lblStatsHeader;
        private Label lblStats;

        // Right Panel
        private Panel panelContent;
        private Label lblGridTitle;
        private Label lblSearch;
        private TextBox txtSearch;
        private Label lblFilter;
        private ComboBox cmbFilter;
        private CheckBox chkShowPassed;
        private DataGridView dgvGrades;
        private Label lblLogTitle;
        private ListBox lstLog;
    }
}
