using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using StudentGradeCalculator.Client.Services;
using StudentGradeCalculator.Shared;

namespace StudentGradeCalculator.Client
{
    public partial class Form1 : Form
    {
        private readonly StudentApiService _apiService;
        private List<Student> _students = new List<Student>();
        private int _selectedId = -1;

        public Form1()
        {
            InitializeComponent();
            _apiService = new StudentApiService("http://localhost:5000");
            WireUpEvents();
            _ = InitializeAsync();
        }

        private async Task InitializeAsync()
        {
            AddLog("Application started. Connecting to API...");
            bool available = await _apiService.IsApiAvailableAsync();
            if (available)
            {
                lblConnectionStatus.ForeColor = Color.FromArgb(166, 227, 161);
                lblConnectionStatus.Text = "\u2705 Connected to API";
                AddLog("Successfully connected to API.");
                await RefreshGridAsync();
            }
            else
            {
                lblConnectionStatus.ForeColor = Color.FromArgb(243, 139, 168);
                lblConnectionStatus.Text = "\u274C API not available - start the API first!";
                AddLog("ERROR: Cannot connect to API at http://localhost:5000");
            }
        }

        private void WireUpEvents()
        {
            btnAdd.Click += BtnAdd_Click;
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete.Click += BtnDelete_Click;
            btnClear.Click += BtnClear_Click;
            txtName.TextChanged += TxtName_TextChanged;
            txtGrade.TextChanged += TxtGrade_TextChanged;
            txtSearch.TextChanged += TxtSearch_TextChanged;
            cmbSubject.SelectedIndexChanged += CmbSubject_SelectedIndexChanged;
            cmbSemester.SelectedIndexChanged += CmbSemester_SelectedIndexChanged;
            cmbFilter.SelectedIndexChanged += CmbFilter_SelectedIndexChanged;
            chkFinalExam.CheckedChanged += ChkFinalExam_CheckedChanged;
            chkShowPassed.CheckedChanged += ChkShowPassed_CheckedChanged;
            dgvGrades.SelectionChanged += DgvGrades_SelectionChanged;
            dgvGrades.CellFormatting += DgvGrades_CellFormatting;
        }

        // BUTTON EVENTS

        private async void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            var student = new Student
            {
                Name = txtName.Text.Trim(),
                Subject = cmbSubject.SelectedItem!.ToString()!,
                Grade = double.Parse(txtGrade.Text.Trim()),
                Semester = cmbSemester.SelectedItem!.ToString()!,
                IsFinalExam = chkFinalExam.Checked
            };

            try
            {
                var created = await _apiService.CreateStudentAsync(student);
                if (created != null)
                {
                    AddLog($"Added: {created.Name} - {created.Subject} - Grade: {created.Grade:F2} ({created.GetLetterGrade()})");
                    lblValidation.ForeColor = Color.FromArgb(166, 227, 161);
                    lblValidation.Text = "\u2705 Grade added successfully!";
                    ClearForm();
                    await RefreshGridAsync();
                }
            }
            catch (Exception ex)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = $"\u274C Error: {ex.Message}";
                AddLog($"ERROR adding student: {ex.Message}");
            }
        }

        private async void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (_selectedId < 0)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Select a record to update.";
                return;
            }
            if (!ValidateInput()) return;

            var student = new Student
            {
                Name = txtName.Text.Trim(),
                Subject = cmbSubject.SelectedItem!.ToString()!,
                Grade = double.Parse(txtGrade.Text.Trim()),
                Semester = cmbSemester.SelectedItem!.ToString()!,
                IsFinalExam = chkFinalExam.Checked
            };

            try
            {
                var updated = await _apiService.UpdateStudentAsync(_selectedId, student);
                if (updated != null)
                {
                    AddLog($"Updated: {updated.Name} - {updated.Subject} - Grade: {updated.Grade:F2}");
                    lblValidation.ForeColor = Color.FromArgb(166, 227, 161);
                    lblValidation.Text = "\u2705 Record updated successfully!";
                    ClearForm();
                    await RefreshGridAsync();
                }
            }
            catch (Exception ex)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = $"\u274C Error: {ex.Message}";
                AddLog($"ERROR updating student: {ex.Message}");
            }
        }

        private async void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (_selectedId < 0)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Select a record to delete.";
                return;
            }

            var selected = _students.FirstOrDefault(s => s.Id == _selectedId);
            string name = selected?.Name ?? "Unknown";

            var result = MessageBox.Show(
                $"Are you sure you want to delete the record for \"{name}\"?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    bool deleted = await _apiService.DeleteStudentAsync(_selectedId);
                    if (deleted)
                    {
                        AddLog($"Deleted: {name}");
                        lblValidation.ForeColor = Color.FromArgb(249, 226, 175);
                        lblValidation.Text = $"\U0001F5D1\uFE0F Record for \"{name}\" deleted.";
                        ClearForm();
                        await RefreshGridAsync();
                    }
                }
                catch (Exception ex)
                {
                    lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                    lblValidation.Text = $"\u274C Error: {ex.Message}";
                    AddLog($"ERROR deleting student: {ex.Message}");
                }
            }
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            ClearForm();
            AddLog("Form cleared.");
        }

        // TEXT CHANGED EVENTS 
        private void TxtName_TextChanged(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Student name is required.";
            }
            else
            {
                lblValidation.Text = "";
            }
        }

        private void TxtGrade_TextChanged(object? sender, EventArgs e)
        {
            if (double.TryParse(txtGrade.Text.Trim(), out double grade))
            {
                if (grade >= 1.0 && grade <= 10.0)
                {
                    var temp = new Student { Grade = grade };
                    string letter = temp.GetLetterGrade();
                    string status = temp.GetStatus();
                    Color color = grade >= 5.0
                        ? Color.FromArgb(166, 227, 161)
                        : Color.FromArgb(243, 139, 168);
                    lblGradePreview.ForeColor = color;
                    lblGradePreview.Text = $"\u2192 {letter} ({status})";
                    lblValidation.Text = "";
                }
                else
                {
                    lblGradePreview.ForeColor = Color.FromArgb(243, 139, 168);
                    lblGradePreview.Text = "\u2192 Invalid range!";
                    lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                    lblValidation.Text = "\u26A0\uFE0F Grade must be between 1 and 10.";
                }
            }
            else if (!string.IsNullOrEmpty(txtGrade.Text))
            {
                lblGradePreview.ForeColor = Color.FromArgb(243, 139, 168);
                lblGradePreview.Text = "\u2192 Not a number!";
            }
            else
            {
                lblGradePreview.Text = "";
            }
        }

        private async void TxtSearch_TextChanged(object? sender, EventArgs e)
        {
            await RefreshGridAsync();
        }

        // COMBOBOX / CHECKBOX EVENTS

        private void CmbSubject_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (cmbSubject.SelectedItem != null) lblValidation.Text = "";
        }

        private void CmbSemester_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (cmbSemester.SelectedItem != null) lblValidation.Text = "";
        }

        private async void CmbFilter_SelectedIndexChanged(object? sender, EventArgs e)
        {
            await RefreshGridAsync();
            if (cmbFilter.SelectedItem != null) AddLog($"Filter changed to: {cmbFilter.SelectedItem}");
        }

        private void ChkFinalExam_CheckedChanged(object? sender, EventArgs e)
        {
            string examType = chkFinalExam.Checked ? "Final Exam" : "Partial Exam";
            lblValidation.ForeColor = Color.FromArgb(205, 214, 244);
            lblValidation.Text = $"Exam type: {examType}";
        }

        private async void ChkShowPassed_CheckedChanged(object? sender, EventArgs e)
        {
            await RefreshGridAsync();
            string status = chkShowPassed.Checked ? "showing passed only" : "showing all";
            AddLog($"Filter: {status}");
        }

        // DATAGRIDVIEW EVENTS

        private void DgvGrades_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvGrades.SelectedRows.Count > 0)
            {
                var row = dgvGrades.SelectedRows[0];
                if (row.Tag is int studentId)
                {
                    var student = _students.FirstOrDefault(s => s.Id == studentId);
                    if (student != null)
                    {
                        _selectedId = student.Id;
                        txtName.Text = student.Name;
                        cmbSubject.SelectedItem = student.Subject;
                        txtGrade.Text = student.Grade.ToString("F2");
                        cmbSemester.SelectedItem = student.Semester;
                        chkFinalExam.Checked = student.IsFinalExam;
                        btnUpdate.Enabled = true;
                        btnDelete.Enabled = true;
                    }
                }
            }
            else
            {
                _selectedId = -1;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void DgvGrades_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvGrades.Columns[e.ColumnIndex].Name == "colStatus" && e.Value != null)
            {
                e.CellStyle.ForeColor = e.Value.ToString() == "Passed"
                    ? Color.FromArgb(166, 227, 161) : Color.FromArgb(243, 139, 168);
                e.CellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            }

            if (dgvGrades.Columns[e.ColumnIndex].Name == "colLetter" && e.Value != null)
            {
                switch (e.Value.ToString())
                {
                    case "A": e.CellStyle.ForeColor = Color.FromArgb(166, 227, 161); break;
                    case "B": e.CellStyle.ForeColor = Color.FromArgb(148, 226, 213); break;
                    case "C": e.CellStyle.ForeColor = Color.FromArgb(249, 226, 175); break;
                    case "D": e.CellStyle.ForeColor = Color.FromArgb(250, 179, 135); break;
                    case "E": e.CellStyle.ForeColor = Color.FromArgb(243, 139, 168); break;
                    case "F": e.CellStyle.ForeColor = Color.FromArgb(235, 111, 146); break;
                }
                e.CellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            }
        }

        //  HELPER METHODS

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Please enter a student name.";
                txtName.Focus();
                return false;
            }
            if (cmbSubject.SelectedIndex < 0)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Please select a subject.";
                cmbSubject.Focus();
                return false;
            }
            if (!double.TryParse(txtGrade.Text.Trim(), out double grade) || grade < 1.0 || grade > 10.0)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Please enter a valid grade (1-10).";
                txtGrade.Focus();
                return false;
            }
            if (cmbSemester.SelectedIndex < 0)
            {
                lblValidation.ForeColor = Color.FromArgb(243, 139, 168);
                lblValidation.Text = "\u26A0\uFE0F Please select a semester.";
                cmbSemester.Focus();
                return false;
            }
            return true;
        }

        private void ClearForm()
        {
            txtName.Clear();
            cmbSubject.SelectedIndex = -1;
            txtGrade.Clear();
            cmbSemester.SelectedIndex = -1;
            chkFinalExam.Checked = false;
            lblValidation.Text = "";
            lblGradePreview.Text = "";
            _selectedId = -1;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            dgvGrades.ClearSelection();
        }

        private async Task RefreshGridAsync()
        {
            try
            {
                string searchText = txtSearch.Text.Trim();
                string filterSubject = cmbFilter.SelectedItem?.ToString() ?? "All Subjects";
                bool showPassedOnly = chkShowPassed.Checked;

                _students = await _apiService.GetStudentsAsync(
                    string.IsNullOrEmpty(searchText) ? null : searchText,
                    filterSubject,
                    showPassedOnly ? true : null
                );

                dgvGrades.Rows.Clear();
                foreach (var s in _students)
                {
                    string examType = s.IsFinalExam ? "Final" : "Partial";
                    int rowIdx = dgvGrades.Rows.Add(
                        s.Name, s.Subject, s.Grade.ToString("F2"),
                        s.GetLetterGrade(), s.Semester, examType,
                        s.GetStatus(), s.DateAdded.ToString("yyyy-MM-dd HH:mm")
                    );
                    dgvGrades.Rows[rowIdx].Tag = s.Id;
                }

                UpdateStats();
            }
            catch (Exception ex)
            {
                AddLog($"ERROR refreshing data: {ex.Message}");
            }
        }

        private void UpdateStats()
        {
            if (_students.Count == 0)
            {
                lblStats.Text = "No grades added yet.";
                return;
            }
            double avg = _students.Average(s => s.Grade);
            double max = _students.Max(s => s.Grade);
            double min = _students.Min(s => s.Grade);
            int passed = _students.Count(s => s.Grade >= 5.0);
            int failed = _students.Count(s => s.Grade < 5.0);

            lblStats.Text = $"Total Records: {_students.Count}\n" +
                            $"Average Grade: {avg:F2}\n" +
                            $"Highest: {max:F2}  |  Lowest: {min:F2}\n" +
                            $"Passed: {passed}  |  Failed: {failed}";
        }

        private void AddLog(string message)
        {
            string entry = $"[{DateTime.Now:HH:mm:ss}] {message}";
            lstLog.Items.Insert(0, entry);
            if (lstLog.Items.Count > 100) lstLog.Items.RemoveAt(lstLog.Items.Count - 1);
        }
    }
}
