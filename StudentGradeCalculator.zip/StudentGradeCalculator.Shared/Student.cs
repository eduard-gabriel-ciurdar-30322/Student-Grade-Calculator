using System.ComponentModel.DataAnnotations;

namespace StudentGradeCalculator.Shared
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Subject { get; set; } = string.Empty;

        public double Grade { get; set; }

        [MaxLength(20)]
        public string Semester { get; set; } = string.Empty;

        public bool IsFinalExam { get; set; }

        public DateTime DateAdded { get; set; } = DateTime.Now;

        public string GetLetterGrade()
        {
            if (Grade >= 9.0) return "A";
            if (Grade >= 8.0) return "B";
            if (Grade >= 7.0) return "C";
            if (Grade >= 6.0) return "D";
            if (Grade >= 5.0) return "E";
            return "F";
        }

        public string GetStatus()
        {
            return Grade >= 5.0 ? "Passed" : "Failed";
        }

        public override string ToString()
        {
            string examType = IsFinalExam ? "Final" : "Partial";
            return $"{Name} | {Subject} | {Grade:F2} ({GetLetterGrade()}) | {Semester} | {examType}";
        }
    }
}
